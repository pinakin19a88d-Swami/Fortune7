$(document).ready(function(){

	$(".mainNav .nav li").removeClass("active");
	$(".subNavList li").removeClass("active");

});